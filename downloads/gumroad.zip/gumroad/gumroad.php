<?php
/*
Plugin Name: Gumroad for WordPress
Plugin URI: http://gumroad.com/
Description: WordPress integration for Gumroad.
Version: 1.0
Author: Andrew Ryno
Author URI: http://andrewryno.com/
License: GPL2
*/

/*  Copyright 2011 Little Big Things LLC

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

*/

add_shortcode( 'gumroad', 'gumroad_shortcode' );
add_filter( 'the_content', 'do_shortcode' );

function gumroad_shortcode( $attributes, $content ) {
	$attributes = shortcode_atts( array(
		'name' => '',
		'url' => '',
		'description' => '',
		'price' => ''
	), $attributes );
	$options = get_option( 'gumroad_options' );
	if ( empty( $options['email'] ) || empty( $options['password'] ) ) {
		return $content;
	} else {
		$post_url = 'http://www.gumroad.com/api/create';
		$fields = array_merge( $attributes, $options );
		$result = json_decode( curl_post( $post_url, $fields ) );
		if ( $result->status == 'success' && ! empty ( $result->url ) ) {
			return '<a href="' . esc_attr( $result->url ) . '">' . esc_html( $content ) . '</a>';
		} else {
			return $content;
		}
	}
}

function curl_post( $url, array $post = NULL, array $options = array() ) {
    $defaults = array(
        CURLOPT_POST => 1,
        CURLOPT_HEADER => 0,
        CURLOPT_URL => $url,
        CURLOPT_FRESH_CONNECT => 1,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_FORBID_REUSE => 1,
        CURLOPT_TIMEOUT => 4,
        CURLOPT_POSTFIELDS => http_build_query( $post )
    );
	
    $ch = curl_init();
    curl_setopt_array( $ch, ( $options + $defaults) ) ;
    if ( ! $result = curl_exec( $ch ) ) {
        trigger_error( curl_error( $ch ) );
    }
    curl_close( $ch );
    return $result;
}

add_action( 'admin_menu', 'gumroad_add_menu' );
function gumroad_add_menu() {
	add_options_page( 'Gumroad Settings', 'Gumroad', 'manage_options', 'gumroad', 'gumroad_options_page' );
}

add_action( 'admin_init', 'gumroad_register_settings' );
function gumroad_register_settings() {
	register_setting( 'gumroad_options', 'gumroad_options', 'gumroad_options_validate' );
	
	add_settings_section( 'gumroad_login_details', 'Login Details', 'gumroad_settings_section', 'gumroad' );
	
	add_settings_field( 'gumroad_email', 'Email Address', 'gumroad_email_field', 'gumroad', 'gumroad_login_details' );
	add_settings_field( 'gumroad_password', 'Password', 'gumroad_password_field', 'gumroad', 'gumroad_login_details' );
}

function gumroad_options_validate( $input ) {
	if ( empty( $input['email'] ) || empty( $input['password'] ) ) {
		add_settings_error( 'gumroad_options', 'empty-fields', 'You must fill out both input fields.' );
	} elseif ( ! is_email( $input['email'] ) ) {
		add_settings_error( 'gumroad_options', 'invalid-email', 'You must enter a valid email address.' );
	} else {
		return $input;
	}
}

function gumroad_settings_section() {
	
}

function gumroad_email_field() {
	$options = get_option( 'gumroad_options' );
	if ( empty( $options ) )
		$options = array( 'email' => '', 'password' => '' );
	echo '<input type="text" name="gumroad_options[email]" value="' . $options['email'] . '" class="regular-text" />';
}

function gumroad_password_field() {
	$options = get_option( 'gumroad_options' );
	if ( empty( $options ) )
		$options = array( 'email' => '', 'password' => '' );
	echo '<input type="password" name="gumroad_options[password]" value="' . $options['password'] . '" class="regular-text" />';
}

function gumroad_options_page() {
	?>
	<div class="wrap">	
		<h2>Gumroad Settings</h2>
		<form method="post" action="options.php">
			<?php settings_fields( 'gumroad_options' ); ?>
			<?php do_settings_sections( 'gumroad' ); ?>
	    	<p class="submit"><input type="submit" class="button-primary" value="<?php _e( 'Save Changes' ); ?>" /></p>
		</form>
	</div>
	<?php
}